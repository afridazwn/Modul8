<?php
// config.php
$dbhost = 'localhost';
$dbuser = 'id21609090_root';
$dbpass = 'Aslk12??mn';
$dbname = 'id21609090_bukutamu';
$conn = mysqli_connect($dbhost,$dbuser,$dbpass) or die('Error connecting to mysql');
mysqli_select_db($conn, $dbname);
?>